<!doctype html>
<html lang="en">
<head>
<body>
	<h1>Laravel Quickstart</h1>

	<p>@yield("content")</p>
</body>
</html>
