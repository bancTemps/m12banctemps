<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', function() {
	return View::make('hello');
});


// Creando una nueva ruta: retorna una string
/*
Route::get('users', function()
{
	return "Users!";
});
*/

// Creando una nueva ruta:
/*
Route::get('users', "UserController@getIndex");
*/
// Cuando nos dirigimos a control, llamamos al método getIndex de la clase UserController.


// Creando una nueva ruta: retorna una vista
Route::get('users', function() {
	return View::make("users");
});
